// Virginia Tech Honor Code Pledge;
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those
// who do.
// -- Anthony Marraccini (amarraccini216)

package game;

import bag.Node;
import bag.SimpleBagInterface;
import student.TestableRandom;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 10/4/2022
 *
 * @param <T>
 */

public class SimpleLinkedBag<T> implements SimpleBagInterface<T> {
    
    private Node<T> firstNode;
    private int numberOfEntries;
    
    /**
     * instantiates fields
     */
    public SimpleLinkedBag() {
        firstNode = null;
        numberOfEntries = 0;
        
    }
    
    /**
     * adds a specified entry to the linked list
     * @param anEntry specified entry to be added
     * @return a boolean if add is successful
     */
    public boolean add(T anEntry) {
        if (anEntry == null) {
            return false;
        }
        else {
            Node<T> node;
            node = new Node<T>(anEntry, firstNode);
            firstNode = node;
            numberOfEntries++;
            return true;
        }
    }
    
    /**
     * finds the size of the current linked list
     * @return the size
     */
    public int getCurrentSize() {
        return numberOfEntries;
    }
    
    /**
     * finds the linked list zero
     * @return boolean if it is empty
     */
    public boolean isEmpty() {
        return numberOfEntries == 0;
    }
    
    /**
     * picks out a random part of the linked list and returns it
     * @return a random part of the linked list
     */
    public T pick() {
        if (isEmpty()) {
            return null;
        }
        else {
            TestableRandom generator = new TestableRandom();
            int index = generator.nextInt(numberOfEntries);
            Node<T> currentNode = firstNode;
            for (int i = 0; i < index; i++) {
                currentNode = currentNode.getNext();
            }
            return currentNode.getData();
        }
    }
    
    /**
     * removes a specified entry from the linked list
     * @param anEntry specified entry to be removed
     * @return a boolean, if remove was successful
     */
    public boolean remove(T anEntry) {
        Node<T> referenceNode = getReferenceTo(anEntry);
        
        if (referenceNode == null) {
            return false;
        }
        else {
            referenceNode.setData(firstNode.getData());
            firstNode = firstNode.getNext();
            numberOfEntries--;
            return true;
        }
    }
    
    /**
     * returns a reference to the Node in the linked lsit
     * @param anEntry
     * @return a reference to the anEntry parameter
     */
    private Node<T> getReferenceTo(T anEntry) {
        boolean found = false;
        Node<T> currentNode;
        currentNode = firstNode;
        
        while (!found && currentNode != null) {
            if (anEntry.equals(currentNode.getData())) {
                found = true;
            }
            else {
                currentNode = currentNode.getNext();
            }
        }
        return currentNode;
    }

}
