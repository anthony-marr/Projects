// Virginia Tech Honor Code Pledge;
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those
// who do.
// -- Anthony Marraccini (amarraccini216)

package game;

public class ProjectRunner {
    
    /**
     * sets up he shape window with the display collection
     * 
     */
    
    public static void main(String[] args) {
        if (args.length > 0) {
            WhackAShape whack = new WhackAShape(args);
        }
        else {
            WhackAShape whack = new WhackAShape();
        }
    }
}
