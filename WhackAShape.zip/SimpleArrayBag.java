// Virginia Tech Honor Code Pledge;
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those
// who do.
// -- Anthony Marraccini (amarraccini216)
package game;

import bag.SimpleBagInterface;
import student.TestableRandom;

/**
 * Anthony Marraccini, amarraccini216
 * @author Student
 * @version 10/4/2022
 *
 * @param <T>
 */
public class SimpleArrayBag<T> implements SimpleBagInterface<T> {
    
    private T[] bag;
    private static final int MAX = 18;
    private int numberOfEntries;
    
    /**
     * instantiates fields
     */
    public SimpleArrayBag() {
        @SuppressWarnings("unchecked")
        T[] tempbag = (T[]) new Object[MAX];
        bag = tempbag;
        numberOfEntries = 0;
    }
    
    /**
     * adds a specified entry to the array bag
     * @return returns boolean based of it it was able to add
     * @param anEntry specified entry to be added
     */
    public boolean add(T anEntry) {
        if (numberOfEntries < 18) {
            bag[numberOfEntries] = anEntry;
            numberOfEntries++;
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * picks out a random part of the array bag and returns it
     * @return returns a random part of array bag
     */
    public T pick() {
        if (isEmpty()) {
            return null;
        }
        else {
            TestableRandom generator = new TestableRandom();
            int index = generator.nextInt(numberOfEntries);
            return bag[index];
        }
        
    }
    /**
     * finds the size of the current array bag
     * @return returns the size
     */
    public int getCurrentSize() {
        return numberOfEntries;
    }
    
    /**
     * finds the array bag empty
     * @return a boolean if bag is empty
     */
    public boolean isEmpty() {
        return numberOfEntries == 0;
    }
    
    /**
     * removes a specified entry from the array bag
     * @return a boolean if remove was successful
     * @param anEntry specified entry to be removed
     */
    public boolean remove(T anEntry) {
        int i = this.getIndexOf(anEntry);
        if (this.getIndexOf(anEntry) == -1) {
            return false;
        }
        else {
            bag[i] = null;
            bag[i] = bag[numberOfEntries - 1];
            numberOfEntries--;
            return true;
        }
    }
    
    /**
     * returns the index of the specified entry
     * @param anEntry
     * @return
     */
    private int getIndexOf(T anEntry) {
        for (int i = 0; i < numberOfEntries; i++) {
            if (anEntry.equals(bag[i])) {
                return i;
            }
        }
        return -1;
    }
    
}
