// Virginia Tech Honor Code Pledge;
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those
// who do.
// -- Anthony Marraccini (amarraccini216)

package game;


import bag.SimpleBagInterface;
import java.awt.Color;
import cs2.Button;
import cs2.CircleShape;
import cs2.Shape;
import cs2.SquareShape;
import cs2.TextShape;
import cs2.Window;
import cs2.WindowSide;
import student.TestableRandom;


/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 10/4/2022
 */
public class WhackAShape {

    private SimpleArrayBag<Shape> bag;
    private Window window;
    private Button quitButton;
    private TestableRandom generateRandom = new TestableRandom();
    
    /**
     * Sets up the buttons, window and bag
     */
    public WhackAShape() {
        window = new Window();
        window.setTitle("Project 2");
        
        bag = new SimpleArrayBag<Shape>();
        
        quitButton = new Button("Quit");
        quitButton.onClick(this, "clickedQuit");
        window.addButton(quitButton, WindowSide.EAST);
        
        int size = 6 +generateRandom.nextInt(8);
        
        String[] bagArray = {"red circle", "blue circle", "red square",
                        "blue square"};
        
        
        for (int i = 0; i < size; i++) {
            int randomShape = 0 + generateRandom.nextInt(4);
            bag.add(buildShape(bagArray[randomShape]));
        }
        Shape shape = bag.pick();
        window.addShape(shape);
    }
    
    /**
     * sets up the buttons, window and bag
     * @param inputs
     */
    public WhackAShape(String[] inputs) {
        window = new Window();
        window.setTitle("Project 2");
        
        bag = new SimpleArrayBag<Shape>();
        
        quitButton = new Button("Quit");
        quitButton.onClick(this, "clickedQuit");
        window.addButton(quitButton, WindowSide.EAST);
        try {
            for (int i = 0; i < inputs.length; i++) {
                Shape shape = buildShape(inputs[i]);
                bag.add(shape);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        window.addShape(bag.pick());
    }
    
    /**
     * sets up and returns bag
     * @return bag
     */
    public SimpleBagInterface<Shape> getBag() {
        return bag;
    }
   
    /**
     * gets window and returns it
     * @return window
     */
    public Window getWindow() {
        return window;
    }
    
    /**
     * when the button it clicked the program shuts down
     * @param button
     */
    public void clickedQuit(Button button) {
        System.exit(0);
    }
    
    /**
     * when the shape is clicked, a new shape pops up
     * @param shape
     */
    public void clickedShape(Shape shape) {
        window.removeShape(shape);
        bag.remove(shape);
        Shape nextShape = bag.pick();
        if (nextShape == null) {
            TextShape text = new TextShape(0, 0, "You Win");
            text.setX((window.getGraphPanelWidth()/2 - (text.getWidth() / 2)));
            text.setY(window.getGraphPanelHeight() / 2 - text.getHeight() / 2);
            window.addShape(text);
        }
        
        else {
            window.addShape(nextShape);
        }
        
    }
    
    /**
     * Takes whatever string is randomly called and creates that shape
     * @param string
     * @return currentShape
     */
    
    private Shape buildShape(String string) {
        TestableRandom generatorSize = new TestableRandom();
        int size = 100 + generatorSize.nextInt(100);
        TestableRandom generatorX = new TestableRandom();
        int xIndex = generatorX.nextInt(window.getWidth() / 2);
        TestableRandom generatorY = new TestableRandom();
        int yIndex = generatorY.nextInt(window.getHeight() / 2);
        int width = (window.getGraphPanelWidth() / 2 - xIndex/2);
        int height = (window.getGraphPanelHeight() / 2 - yIndex/ 2);
        Color color;
        Shape currentShape;
        if (string.contains("blue")) {
            color = Color.BLUE;
        }
        else if (string.contains("red")) {
            color = Color.RED;
        }
        else {
            throw new IllegalArgumentException();
        }
        
        if (string.contains("circle")) {
            currentShape = new CircleShape(width, height, size, color);
        }
        
        else if (string.contains("square")) {
            currentShape = new SquareShape(width, height, size, color);
        }
        
        else {
            throw new IllegalArgumentException();
        }
        
        currentShape.onClick(this, "clickedShape");
        return currentShape;
    }
}
