// Virginia Tech Honor Code Pledge;
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those
// who do.
// -- Anthony Marraccini (amarraccini216)

package game;

import student.TestableRandom;

/**
 * @author Anthony Marraccini, amarraccini216
 * @version 10/4/2022
 */
public class SimpleArrayBagTest extends student.TestCase {
    private SimpleArrayBag<String> testBag;
    
    /**
     * sets up for tests
     */
    public void setUp() {
        testBag = new SimpleArrayBag<String>();
    }
    
    /**
     * tests to make sure the add method returns expected
     */
    public void testAdd() {
        testBag.add("square");
        assertEquals(1, testBag.getCurrentSize());
        for (int i = 0; i < 19; i++) {
            testBag.add("square");
        }
        assertFalse(testBag.add("square"));
    }
    
    /**
     * tests to make sure the pick method returns expected
     */
    public void testPick() {
        assertNull(testBag.pick());
        TestableRandom.setNextInts(0, 1, 2);
        testBag.add("circle");
        testBag.add("square");
        testBag.add("trapezoid");
        assertEquals("circle", testBag.pick());
        assertEquals("square", testBag.pick());
        assertEquals("trapezoid", testBag.pick());
    }
    
    /**
     * tests to make sure the size method returns expected
     */
    public void testGetCurrentSize() {
        testBag.add("circle");
        assertEquals(1, testBag.getCurrentSize());
    }
    
    /**
     * tests to make sure the empty method returns expected
     */
    public void testIsEmpty() {
        assertTrue(testBag.isEmpty());
        testBag.add("circle");
        assertFalse(testBag.isEmpty());
    }
    
    /**
     * tests to make sure the remove method returns expected
     */
    public void testRemove() {
        testBag.add("circle");
        assertFalse(testBag.remove("square"));
        testBag.add("square");
        testBag.add("square");
        assertTrue(testBag.remove("square"));
    }
}
