// Virginia Tech Honor Code Pledge;
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of those
// who do.
// -- Anthony Marraccini (amarraccini216)

package game;

import student.TestableRandom;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 10/4/2022
 *
 */

public class SimpleLinkedBagTest extends student.TestCase {
    private SimpleLinkedBag<String> testBag;
    
    /**
     * sets up for tests
     */
    public void setUp() {
        testBag = new SimpleLinkedBag<String>();
    }
    
    /**
     * tests to make sure the add method returns expected
     */
    public void testAdd() {
        assertFalse(testBag.add(getName()));
        testBag.add("circle");
        assertEquals(1, testBag.getCurrentSize());
        assertTrue(testBag.add("square"));
    }
    
    /**
     * tests to make sure the size method returns expected
     */
    public void testGetCurrentSize() {
        assertEquals(0, testBag.getCurrentSize());
        testBag.add("circle");
        assertEquals(1, testBag.getCurrentSize());
    }
    
    /**
     * tests to make sure the empty method returns expected
     */
    public void testIsEmpty() {
        assertTrue(testBag.isEmpty());
        testBag.add("circle");
        assertFalse(testBag.isEmpty());
    }
    
    /**
     * tests to make sure the pick method returns expected
     */
    public void testPick() {
        assertNull(testBag.pick());
        TestableRandom.setNextInts(0, 1, 3);
        testBag.add("circle");
        testBag.add("square");
        testBag.add("trapezoid");
        assertEquals("trapezoid", testBag.pick());
        assertEquals("square", testBag.pick());
        assertEquals("trapezoid", testBag.pick());
    }
    
    /**
     * tests to make sure the remove method returns expected
     */
    public void testRemove() {
        assertFalse(testBag.remove("circle"));
        assertFalse(testBag.remove(null));
        testBag.add("circle");
        testBag.add("square");
        assertTrue(testBag.remove("circle"));
    }
}
