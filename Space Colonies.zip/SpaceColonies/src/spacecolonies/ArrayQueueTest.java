// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;

import queue.EmptyQueueException;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/1/2022
 *
 */

public class ArrayQueueTest extends student.TestCase {
    private ArrayQueue<String> queue;
    
    /**
     * sets up queue to be tested on
     */
    public void setUp() {
        queue = new ArrayQueue<String>(20);
    }
    
    /**
     * tests if the underlyingArray length works
     */
    public void testGetLengthOfUnderlyingArray() {
        assertEquals(21, queue.getLengthOfUnderlyingArray());
        queue.enqueue("B");
        queue.enqueue("C");
        assertEquals(21, queue.getLengthOfUnderlyingArray());
        for (int i = 0; i < 12; i++) {
            queue.enqueue("A");
        }
        assertEquals(21, queue.getLengthOfUnderlyingArray());
        queue.clear();
        assertEquals(21, queue.getLengthOfUnderlyingArray());
    }
    
    /**
     * tests if the getSize method works
     */
    public void testGetSize() {
        assertEquals(0, queue.getSize());
        queue.enqueue("A");
        assertEquals(1, queue.getSize());
    }
    
    /**
     * tests if the IsEmpty method works
     */
    public void testIsEmpty() {
        assertTrue(queue.isEmpty());
        queue.enqueue("A");
        assertFalse(queue.isEmpty());
    }
    
    /**
     * tests if the Enqueue method works
     */
    public void testEnqueue() {
        queue.enqueue("A");
        assertEquals(queue.getFront(), "A");
        assertEquals(1, queue.getSize());
        queue.enqueue("B");
        assertEquals(2, queue.getSize());
        for (int i = 2; i < ArrayQueue.DEFAULT_CAPACITY; i++) {
            queue.enqueue("C");
        }
        queue.enqueue("A");
        queue.enqueue("A");
        queue.enqueue("A");
        assertEquals("A", queue.dequeue());
        assertEquals("B", queue.dequeue());
        assertEquals("C", queue.dequeue());
        assertEquals("C", queue.dequeue());
        queue.clear();
        queue.enqueue("A");
        assertEquals("A", queue.dequeue());
        queue.clear();
        queue.enqueue("A");
        queue.enqueue("B");
        queue.enqueue("C");
        assertEquals("A", queue.dequeue());
        assertEquals("B", queue.dequeue());
    }
    
    
    /**
     * tests if the Dequeue method works
     */
    public void testDequeue() {
        Exception thrown = null;
        try {
            queue.dequeue();
        }
        catch (EmptyQueueException exception) {
            thrown = exception;
        }
        queue.enqueue("A");
        queue.enqueue("B");
        assertEquals("A", queue.dequeue());
        assertEquals("B", queue.dequeue());
        queue.enqueue("A");
        queue.enqueue("B");
        queue.enqueue("C");
        queue.enqueue("D");
        assertEquals("A", queue.dequeue());
        assertEquals("B", queue.dequeue());
        assertEquals("C", queue.dequeue());
        queue.enqueue("E");
        assertEquals("D", queue.dequeue());
        assertEquals("E", queue.dequeue());
    }
    
    /**
     * tests if the getFront method works
     */
    public void testGetFront() {
        Exception thrown = null;
        try {
            queue.getFront();
        }
        catch (EmptyQueueException exception) {
            thrown = exception;
        }
        queue.enqueue("A");
        queue.enqueue("B");
        assertEquals("A", queue.getFront());
    }
    
    /**
     * tests is the clear method works
     */
    public void testClear() {
        queue.enqueue("A");
        queue.enqueue("A");
        assertEquals(2, queue.getSize());
        queue.clear();
        assertEquals(0, queue.getSize());
        Exception thrown = null;
        try {
            queue.getFront();
        }
        catch (EmptyQueueException exception) {
            thrown = exception;
        }
    }

    /**
     * tests if the ToArray method works
     */
    public void testToArray() {
        Exception thrown = null;
        try {
            queue.toArray();
        }
        catch (EmptyQueueException exception) {
            thrown = exception;
        }
        
        String[] stringArray = new String[3];
        stringArray[0] = "A";
        stringArray[1] = "B";
        stringArray[2] = "C";
        queue.enqueue(stringArray[0]);
        queue.enqueue(stringArray[1]);
        queue.enqueue(stringArray[2]);
        for (int i = 0; i < stringArray.length; i++) {
            assertEquals(queue.toArray()[i], stringArray[i]);
        }
    }
    
    /**
     * tests if the ToString method works
     */
    public void testToString() {
        assertEquals("[]", queue.toString());
        queue.enqueue("A");
        queue.enqueue("B");
        queue.enqueue("C");
        assertEquals("[A, B, C]", queue.toString());
        queue.dequeue();
        assertEquals("[B, C]", queue.toString());
        queue.enqueue("D");
        queue.enqueue("E");
        assertEquals("[B, C, D, E]", queue.toString());
        queue.dequeue();
        queue.dequeue();
        assertEquals("[D, E]", queue.toString());
    }
    
    /**
     * tests if the Equals method works
     */
    public void testEquals() {
        queue.enqueue("A");
        queue.enqueue("B");
        queue.enqueue("C");
        ArrayQueue<String> sameQueue = new ArrayQueue<String>(20);
        ArrayQueue<String> diffQueue = new ArrayQueue<String>(20);
        ArrayQueue<String> diffSize = new ArrayQueue<String>(20);
        sameQueue.enqueue("A");
        sameQueue.enqueue("B");
        sameQueue.enqueue("C");
        diffQueue.enqueue("C");
        diffQueue.enqueue("A");
        diffQueue.enqueue("B");
        diffSize.enqueue("A");
        diffSize.enqueue("B");
        assertFalse(queue.equals(null));
        assertTrue(queue.equals(queue));
        assertFalse(queue.equals(""));
        assertFalse(queue.equals(diffSize));
        assertTrue(queue.equals(sameQueue));
        assertFalse(queue.equals(diffQueue));
        diffSize.clear();
        diffQueue.clear();
        diffSize.enqueue("A");
        diffSize.enqueue("B");
        diffSize.enqueue("C");
        diffQueue.enqueue("A");
        diffQueue.enqueue("B");
        diffQueue.enqueue("C");
        assertTrue(diffSize.equals(diffQueue));
        diffSize.dequeue();
        diffQueue.dequeue();
        assertTrue(diffSize.equals(diffQueue));
        diffSize.dequeue();
        diffQueue.dequeue();
        assertTrue(diffSize.equals(diffQueue));
        diffSize.dequeue();
        diffQueue.dequeue();
        assertTrue(diffSize.equals(diffQueue));
    }
}
