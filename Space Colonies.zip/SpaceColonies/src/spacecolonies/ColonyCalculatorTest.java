// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;


/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/8/2022
 *
 */
public class ColonyCalculatorTest extends student.TestCase {
    private Planet[] planetArray;
    private Planet planet0;
    private Planet planet1;
    private Planet planet2;
    private Planet planet3;
    private Person person1;
    private Person person2;
    private Person person3;
    private Person person4;
    private Person person5;
    private ColonyCalculator calculator;
    
    /**
     * sets up objects for testing
     */
    public void setUp() {
        planetArray = new Planet[4];
        
        planet0 = new Planet("1", 3, 3, 3, 2);
        planet1 = new Planet("2", 3, 3, 3, 3);
        planet2 = new Planet("6", 2, 2, 2, 5);
        planet3 = new Planet("5", 2, 2, 2, 1);
        
        person1 = new Person("A", 3, 3, 3, "1");
        person2 = new Person("B", 4, 4, 4, "2");
        person3 = new Person("B", 2, 2, 2, "3");
        person4 = new Person("B", 5, 5, 5, "6");
        person5 = new Person("B", 1, 1, 1, "5");
        ArrayQueue<Person> array = new ArrayQueue<Person>(3);
        array.enqueue(person1);
        array.enqueue(person2);
        planetArray[0] = planet0;
        planetArray[1] = planet1;
        planetArray[2] = planet2;
        planetArray[3] = planet3;
        calculator = new ColonyCalculator(array, planetArray);
    }
    
    /**
     * tests if the getQueue method works
     */
    public void testGetQueue() {
        ArrayQueue<Person> nullArray = null;
        Exception thrown = null;
        try {
            ColonyCalculator calc2 = new ColonyCalculator(
                nullArray, planetArray);
        }
        catch (IllegalArgumentException exception) {
            thrown = exception;
        }
        ArrayQueue<Person> testingArray = new ArrayQueue<Person>(3);
        testingArray.enqueue(person1);
        testingArray.enqueue(person2);
        assertEquals(calculator.getQueue(), testingArray);
    }
    
    /**
     * tests if the getPlanets method works
     */
    public void testGetPlanets() {
        Planet[] testArray = new Planet[4];
        testArray[0] = planet0;
        testArray[1] = planet1;
        testArray[2] = planet2;
        testArray[3] = planet3;
        assertEquals(calculator.getPlanets()[0], testArray[0]);
        assertEquals(calculator.getPlanets()[1], testArray[1]);
        assertEquals(calculator.getPlanets()[2], testArray[2]);
        assertEquals(calculator.getPlanets()[3], testArray[3]);
    }
    
    /**
     * tests if the getPlanetForPerson method works
     */
    public void testGetPlanetForPerson() {
        assertNull(calculator.getPlanetForPerson(null));
        Planet[] testArray = new Planet[4];
        testArray[0] = planet2;
        testArray[1] = planet1;
        testArray[2] = planet0;
        testArray[3] = planet3;
        assertEquals(calculator.getPlanetForPerson(person1), planet0);
        planet0.addPerson(person1);
        planet0.addPerson(person1);
        assertNull(calculator.getPlanetForPerson(person1));
        assertEquals(calculator.getPlanetForPerson(person2), planet1);
        assertNull(calculator.getPlanetForPerson(person3));
        assertNull(calculator.getPlanetForPerson(person5));
        assertEquals(calculator.getPlanetForPerson(person4), planet2);
        assertEquals(calculator.getPlanetForPerson(person4), testArray[0]);
        for (int i = 0; i < testArray.length; i++) {
            assertEquals(calculator.getPlanets()[i], testArray[i]);
        }
    }
    
    /**
     * tests if the accept method works
     */
    public void testAccept() {
        ArrayQueue<Person> newArray = new ArrayQueue<Person>(3);
        ColonyCalculator calc2 = new ColonyCalculator(newArray, 
            planetArray);
        
        assertFalse(calc2.accept());
        Person person6 = new Person("A6", 3, 3, 3, null);
        
        newArray.enqueue(person6);
        assertFalse(calc2.accept());
        
        newArray.dequeue();
        newArray.enqueue(person1);
        
        assertTrue(calc2.accept());

        newArray.enqueue(person2);
        assertTrue(calc2.accept());
        
        newArray.enqueue(person3);
        assertTrue(calc2.accept());
    }
    
    /**
     * test if the reject method works
     */
    public void testReject() {
        ArrayQueue<Person> newArray = new ArrayQueue<Person>(3);
        newArray.enqueue(person2);
        calculator.reject();
        assertEquals(newArray, calculator.getQueue());
    }
    
    /**
     * tests if the getPlanetIndex method works
     */
    public void testGetPlanetindex() {
        assertEquals(-1, calculator.getPlanetIndex(null));
        assertEquals(0, calculator.getPlanetIndex(
            person1.getPlanetPreference()));
        assertEquals(1, calculator.getPlanetIndex(
            person2.getPlanetPreference()));
        assertEquals(2, calculator.getPlanetIndex(
            person3.getPlanetPreference()));
        assertEquals(-1, calculator.getPlanetIndex(
            person4.getPlanetPreference()));
    }
}
