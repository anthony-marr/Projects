// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/8/2022
 *
 */
public class ColonyReader {
    private Planet[] planets;
    private ArrayQueue<Person> queue;
    
    
    /**
     * sets up the Colony Reader class
     * @param applicantFileName
     *                  string of applicant file name
     * @param planetFileName
     *                  string of planet file name
     * @throws FileNotFoundException
     * @throws java.text.ParseException
     * @throws SpaceColonyDataException
     */
    public ColonyReader(String applicantFileName, String planetFileName) 
                    throws FileNotFoundException, 
                       java.text.ParseException,
                        SpaceColonyDataException {
        queue = readQueueFile(applicantFileName);
        planets = readPlanetFile(planetFileName);
        ColonyCalculator calc = new ColonyCalculator(queue, planets);
        SpaceWindow spaceWindow = new SpaceWindow(calc);
    }
    
    /**
     * reads the planet file and parses it
     * @param fileName
     *          string of planet file name
     * @return Planet Array from text file
     * @throws FileNotFoundException
     * @throws java.text.ParseException
     */
    private Planet[] readPlanetFile(String fileName) 
        throws FileNotFoundException,
        java.text.ParseException {
        
        planets = new Planet[3];
        Scanner file = new Scanner(new File(fileName));
        int lineCount = 0;
        int dataCount = 0;
        while (file.hasNextLine() && lineCount < 4) {
            String read = file.nextLine();
            Scanner currLine = new Scanner(read).useDelimiter(",\\s*");
            String[] tokens = new String[5];
            int tokenCount = 0;
            while (currLine.hasNext() && tokenCount < 5) {
                tokens[tokenCount] = currLine.next();
                tokenCount++;
            }
            currLine.close();
            if (tokenCount > 3 && tokenCount <= 5) {
                planets[dataCount] = new Planet(tokens[0],
                    Integer.valueOf(tokens[1]),
                    Integer.valueOf(tokens[2]),
                    Integer.valueOf(tokens[3]),
                    Integer.valueOf(tokens[4]));
                dataCount++;
            }
            else {
                throw new java.text.ParseException("parse exception", 1);
            }
            lineCount++;
        }
        file.close();
        return planets;
    }
    
    /**
     * reads the applicant file
     * @param fileName
     *          string name of applicant text file
     * @return a queue of applicants
     * @throws FileNotFoundException
     * @throws java.text.ParseException
     * @throws SpaceColonyDataException
     */
    private ArrayQueue<Person> readQueueFile(String fileName) 
            throws FileNotFoundException,
                java.text.ParseException,
                SpaceColonyDataException {
        
        queue = new ArrayQueue<Person>(ArrayQueue.DEFAULT_CAPACITY);
        Scanner scan = new Scanner(new File(fileName));
        int lineCount = 0;
        int dataCount = 0;
        while (scan.hasNextLine() && lineCount < 25) {
            String read = scan.nextLine();
            Scanner currLine = new Scanner(read).useDelimiter(",\\s*");
            String[] tokens = new String[5];
            int tokenCount = 0;
            while (currLine.hasNext() && tokenCount <= 5) {
                tokens[tokenCount] = currLine.next();
                tokenCount++;
            }
            currLine.close();
            if (tokenCount > 3 && tokenCount <= 5) {
                int one = Integer.valueOf(tokens[1]);
                int two = Integer.valueOf(tokens[2]);
                int three = Integer.valueOf(tokens[3]);
                
                
                if (isInSkillRange(one, two, three)) {
                    queue.enqueue( new Person(
                        tokens[0], one, two, three, tokens[4]));
                    dataCount++;
                }
                else {
                    throw new SpaceColonyDataException("Skills are"
                        + " not in range");
                }
                
            }
            else {
                throw new java.text.ParseException("parse exception", 1);
            }
            lineCount++;
        }
        scan.close();
        return queue;
    }
    
    /**
     * checks to make sure that they're in the range
     * @param num1
     *          ag skill
     * @param num2
     *          medicine skill
     * @param num3
     *          tech skill
     * @return boolean whether its in range of not
     */
    private boolean isInSkillRange(int num1, int num2, int num3) {
        if (num1 >= ColonyCalculator.MIN_SKILL_LEVEL && 
            num1 <= ColonyCalculator.MAX_SKILL_LEVEL) {
            if (num2 >= ColonyCalculator.MIN_SKILL_LEVEL && 
                num2 <= ColonyCalculator.MAX_SKILL_LEVEL) {
                if (num3 >= ColonyCalculator.MIN_SKILL_LEVEL && 
                    num3 <= ColonyCalculator.MAX_SKILL_LEVEL) {
                    return true;
                }
            }
        }
        return false;
    }
}
