// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;

import java.io.FileNotFoundException;

/**
 * @author Anthony Marraccini, amarraccini216
 * @version 11/8//2022
 *
 */
public class ProjectRunner {
    
    /**
     * sets up class
     */
    public ProjectRunner() {
        //hello
    }
    
    /**
     * main method that runs project
     * @param args
     *          a sequence to be added to colony reader
     * @throws FileNotFoundException
     * @throws java.text.ParseException
     * @throws SpaceColonyDataException
     */
    public static void main(String[] args) 
        throws FileNotFoundException, 
        java.text.ParseException, 
        SpaceColonyDataException {
        if (args.length == 2) {
            ColonyReader reader = new ColonyReader(args[0], args[1]);
        }
        else {
            ColonyReader reader = new ColonyReader("input.txt", "planets.txt");    
        }
    }
}
