// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/1/2022
 *
 */
public class PersonTest extends student.TestCase {
    private Person person;
    private Person equalPerson;
    private Person diffName;
    private Person diffSkills;
    private Person diffPlanet;
    private Person noPref;
    private Person nullPref;
    
    /**
     * sets up objects for test methods
     */
    public void setUp() {
        person = new Person("Anthony", 4, 3, 5, "Earth");
        equalPerson = new Person("Anthony", 4, 3, 5, "Earth");
        diffName = new Person("Harrison", 4, 3, 5, "Earth");
        diffSkills = new Person("Anthony", 3, 4, 3, "Earth");
        diffPlanet = new Person("Anthony", 4, 3, 5, "Mars");
        noPref = new Person("Anthony", 4, 3, 5, "");
        nullPref = new Person("Anthony", 4, 3, 5, null);
    }
    
    /**
     * tests to see if getName method works
     */
    public void testGetName() {
        assertEquals(person.getName(), "Anthony");
    }
    
    /**
     * tests to see if getSkills method works
     */
    public void testGetSkills() {
        assertEquals(person.getSkills().getAgriculture(), 4);
        assertEquals(person.getSkills().getMedicine(), 3);
        assertEquals(person.getSkills().getTechnology(), 5);
    }
    
    /**
     * tests to see if getPlanetPreference method works
     */
    public void testeGetPlanetPreference() {
        assertEquals(person.getPlanetPreference(), "Earth");
        assertEquals(equalPerson.getPlanetPreference(), "Earth");
        assertEquals(diffPlanet.getPlanetPreference(), "Mars");
        assertNull(nullPref.getPlanetPreference());
    }
    
    /**
     * tests to see if toString method works
     */
    public void testToString() {
        assertEquals(person.toString(), "Anthony A:4 M:3 T:5 Wants: Earth");
        assertEquals(noPref.toString(), "Anthony A:4 M:3 T:5" +
            " Wants: ");
        assertEquals(nullPref.toString(), "Anthony A:4 M:3 T:5" +
            " Has No Preference");
    }
    
    /**
     * tests to see if equals method works
     */
    public void testEquals() {
        assertTrue(person.equals(equalPerson));
        assertFalse(person.equals(diffName));
        assertFalse(person.equals(diffPlanet));
        assertFalse(person.equals(diffSkills));
    }
}
