// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;

import queue.EmptyQueueException;
import queue.QueueInterface;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 10/31/2022
 *
 * @param <T>
 */
public class ArrayQueue<T> implements QueueInterface<T> {
    
    private T[] queue;
    /**
     * default capacity
     */
    public static final int DEFAULT_CAPACITY = 20;
    private int enqueueIndex;
    private int dequeueIndex;
    private int size;
    
    /**
     * creates new queue object
     * @param capacity
     *              the capacity of the object
     */
    public ArrayQueue(int capacity) {
        queue = (T[]) new Object[capacity + 1];
        size = 0;
        dequeueIndex = 0;
        enqueueIndex = queue.length - 1;
    }
    
    /**
     * gets the underlying length of array
     * @return int of length
     */
    public int getLengthOfUnderlyingArray() {
        return queue.length;
    }
    
    /**
     * gets size 
     * @return int of size
     */
    public int getSize() {
        return size;
    }
    
    /**
     * checks to see if list is empty
     * @return boolean if empty or not
     */
    public boolean isEmpty() {
        return size == 0;
    }
    
    /**
     * checks to see if list has reached capacity
     * @return boolean where is is or not
     */
    private boolean isFull() {
        return size == DEFAULT_CAPACITY;
    }
    
    /**
     * enqueues an object into queue
     * @param obj
     *          object that is being added
     */
    public void enqueue(T obj) {
        ensureCapacity();
        enqueueIndex = incrementIndex(enqueueIndex);
        queue[enqueueIndex] = obj;
        size++;
    }
    
    /**
     * expands capacity by 2
     */
    private void ensureCapacity() {
        if (isFull()) {
            T[] copy = queue;
            int lengthQueue = queue.length;
            T[] newQueue = (T[]) new Object[(2 * (lengthQueue - 1)) + 1];
            int copyIndex = dequeueIndex;
            for (int i = 0; i < size; i++) {
                newQueue[i] = copy[copyIndex];
                copyIndex = (copyIndex + 1) % lengthQueue;
            }
            queue = newQueue;
            dequeueIndex = 0;
            enqueueIndex = lengthQueue - 2;
        }
    }
    
    /**
     * dequeues the first object in queue
     * @return the object that was removed
     */
    public T dequeue() {
        if (size == 0) {
            throw new EmptyQueueException();
        }
        T temp = getFront();
        queue[dequeueIndex] = null;
        dequeueIndex = incrementIndex(dequeueIndex);
        size--;
        return temp;
    }
    
    /**
     * returns the front object value in queue
     * @return object in front of queue
     */
    public T getFront() {
        if (size == 0) {
            throw new EmptyQueueException();
        }
        return queue[dequeueIndex];
    }
    
    /**
     * clears all the objects from the queue
     */
    public void clear() {
        T[] newQueue = (T[]) new Object[DEFAULT_CAPACITY + 1];
        size = 0;
        enqueueIndex = incrementIndex(DEFAULT_CAPACITY - 1);
        dequeueIndex = 0;
        queue = newQueue;
    }
    
    /**
     * increments the index by desired value
     * @param index
     *          desire index
     * @return value of increase
     */
    private int incrementIndex(int index) {
        return ((index + 1) % queue.length);
    }
    
    /**
     * returns object in array form
     * @return form of array
     */
    public Object[] toArray() {
        Object[] array = new Object[size];
        if (isEmpty()) {
            throw new EmptyQueueException();
        }
        int front = dequeueIndex;
        for (int i = 0; i < size; i++) {
            if (queue[front] != null) {
                array[i] = queue[front];
                front = incrementIndex(front);
            }
        }
        return array;
    }
    
    /**
     * returns string in String form
     * @return the sequence in string form
     */
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("[");
        for (int i = 0; i < size; i++) {
            s.append(queue[dequeueIndex + i]);
            if (i != size - 1) {
                s.append(", ");
            }
        }
        s.append("]");
        return s.toString();
    }
    
    /**
     * checks to see if two of them are equal
     * @param obj
     *          the object that is being compared
     * @return a boolean whether equal or not
     */
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (obj.getClass() != this.getClass()) {
            return false;
        }
        ArrayQueue<T> other = (ArrayQueue<T>)obj;
        if (other.getSize() != this.getSize()) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            T myElement = queue[(dequeueIndex + i) % queue.length];
            T otherElement = other.queue[(other.dequeueIndex + i) 
                                         % other.queue.length];
            if (!myElement.equals(otherElement)) {
                return false;
            }
        }
        return true;
    }
}
