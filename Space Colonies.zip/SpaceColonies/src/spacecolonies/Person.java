// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/1/2022
 *
 */
public class Person {
    private String name;
    private Skillset skills;
    private String planetPreference;
    
    /**
     * sets up person object with parameters
     * @param name
     *          name of person
     * @param agriculture
     *          agriculture skill of person
     * @param medicine
     *          medicine skill of person
     * @param technology
     *          technology skill of person
     * @param pref
     *          preference of certain planet
     */
    public Person(String name, int agriculture, int medicine, 
        int technology, String pref) {
        this.name = name;
        skills = new Skillset(agriculture, medicine, technology);
        this.planetPreference = pref;
    }
    
    /**
     * gets name of the person
     * @return name of the person
     */
    public String getName() {
        return name;
    }
    
    /**
     * gets skillset of person
     * @return skillset
     */
    public Skillset getSkills() {
        return skills;
    }
    
    /**
     * gets planet preference
     * @return preference
     */
    public String getPlanetPreference() {
        return planetPreference;
    }
    
    /**
     * converts person to a string sequence
     * @return string sequence of person
     */
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(name);
        s.append(" A:");
        s.append(skills.getAgriculture());
        s.append(" M:");
        s.append(skills.getMedicine());
        s.append(" T:");
        s.append(skills.getTechnology());
        if (planetPreference != null) {
            s.append(" Wants: ");
            s.append(planetPreference);
        }
        else {
            s.append(" Has No Preference");
        }
        return s.toString();
    }
    
    /**
     * check to see if a person is the same as another person
     * @param obj
     *          object to be compared
     * @return a boolean value if they're equal or not
     */
    public boolean equals(Object obj) {
        Person other = (Person)obj;
        if ((this.getName() == other.getName())) {
            if (this.getSkills().equals(other.getSkills())) {
                if (this.getPlanetPreference() == 
                    other.getPlanetPreference()) {
                    return true;
                }
            }
        }
        return false;
    }
}
