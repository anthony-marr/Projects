// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/4/2022
 *
 */
public class Planet implements Comparable<Planet> {
    private String name;
    private Skillset minSkills;
    private Person[] population;
    private int populationSize;
    private final int capacity;
    
    /**
     * public setup method
     * @param planetName
     *              name of planet
     * @param planetAgri
     *              agriculture level
     * @param planetMedi
     *              medical level
     * @param planetTech
     *              technology level
     * @param planetCap
     *              planet capacity
     */
    public Planet(String planetName, int planetAgri,
        int planetMedi, int planetTech, int planetCap) {
        this.name = planetName;
        this.minSkills = new Skillset(planetAgri, planetMedi, planetTech);
        this.capacity = planetCap;
        population = new Person[planetCap];
        populationSize = 0;
    }
    
    /**
     * sets the planet name
     * @param name
     *          specified planet name
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * gets the planet name
     * @return planet name
     */
    public String getName() {
        return name;
    }
    
    /**
     * gets the skillset
     * @return skillset
     */
    public Skillset getSkills() {
        return minSkills;
    }
    
    /**
     *  gets the population
     * @return population
     */
    public Person[] getPopulation() {
        return population;
    }
    
    /**
     * gets the population size
     * @return population size
     */
    public int getPopulationSize() {
        return populationSize;
    }
    
    /**
     * gets the capacity
     * @return capacity
     */
    public int getCapacity() {
        return capacity;
    }
    
    /**
     * gets the availability
     * @return availability
     */
    public int getAvailability() {
        int availability = capacity - populationSize;
        return availability;
    }
    
    /**
     * checks if it is full
     * @return boolean whether full or not
     */
    public boolean isFull() {
        return (populationSize == capacity);
    }
    /**
     * checks to see if a person is qualified
     * @param applicant
     *              the person to see if they're qualified
     * @return boolean whether qualified or not
     */
    public boolean isQualified(Person applicant) {
        if ((minSkills.getAgriculture() <= 
            applicant.getSkills().getAgriculture())) {
            if (minSkills.getMedicine() <= 
                applicant.getSkills().getMedicine()) {
                if (minSkills.getTechnology() <=
                    applicant.getSkills().getTechnology()) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * adds a personto the population array
     * @param newbie
     *          person to be added
     * @return boolean whether they were added or not
     */
    public boolean addPerson(Person newbie) {
        if ((!isFull()) && isQualified(newbie)) {
            population[populationSize] = newbie;
            populationSize++;
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * returns string sequence
     * @return string sequence
     */
    public String toString() {
        StringBuilder pop = new StringBuilder();
        pop.append(name + ", population ");
        pop.append(populationSize + " (cap: " + capacity + "), " +
            "Requires: A >= " + minSkills.getAgriculture() + ", M >= " + 
            minSkills.getMedicine() + ", T >= " + minSkills.getTechnology());
        return pop.toString();
    }
    
    /**
     * compares two planets
     * @param other
     *          planet to compare
     * @return integer of comparison
     */
    public int compareTo(Planet other) {
        return this.capacity - other.capacity;
    }
    
    /**
     * checks to see if they're equal
     * @param obj
     *          object to check to see if they're equal
     * @return boolean if equal or not
     */
    public boolean equals(Object obj) {
        Planet other = (Planet)obj;
        if ((name == other.name))  {
            if (minSkills.getAgriculture() == 
                other.minSkills.getAgriculture()) {
                if (minSkills.getMedicine() == 
                    other.minSkills.getMedicine()) {
                    if (minSkills.getTechnology() == 
                        other.minSkills.getTechnology()) {
                        if (capacity == other.capacity) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
}
