// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;


import list.AList;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/4/2022
 *
 */
public class ColonyCalculator {
    /**
     * default num planets
     */
    public static final int NUM_PLANETS = 3;
    /**
     * default minimum skill
     */
    public static final int MIN_SKILL_LEVEL = 1;
    /**
     * default max skill
     */
    public static final int MAX_SKILL_LEVEL = 5;
    private ArrayQueue<Person> applicantQueue;
    private AList<Person> rejectBus;
    private Planet[] planets;
    
    /**
     * Sets up colony Calculator class
     * @param queue
     *          the queue of people
     * @param planet
     *          the array of planets
     */
    public ColonyCalculator(ArrayQueue<Person> queue, Planet[] planet) {
        this.applicantQueue = queue;
        this.planets = planet;
        if (applicantQueue == null) {
            throw new IllegalArgumentException();
        }
        this.rejectBus = new AList<Person>(queue.getSize());
    }
    
    /**
     * gets the applicant queue
     * @return the applicant queue
     */
    public ArrayQueue<Person> getQueue() {
        return applicantQueue;
    }
    
    /**
     * gets the array of planets
     * @return the array of planets
     */
    public Planet[] getPlanets() {
        return planets;
    }
    
    private boolean canAccept(Planet planet, Person person) {
        if (planet.isFull()) {
            return false;
        }
        return (planet.getSkills().isLessThanOrEqualTo(person.getSkills()));
    }
    
    /**
     * gets whatever Planet is best for that person
     * @param nextPerson
     *              Person who is evaluated
     * @return the planet they are best for
     */
    public Planet getPlanetForPerson(Person nextPerson) {
        if (nextPerson == null) {
            return null;
        }
        String preference = nextPerson.getPlanetPreference();
        if (getPlanetIndex(preference) == 0 ||
            getPlanetIndex(preference) == 1 ||
            getPlanetIndex(preference) == 2) {
            for (int i = 0; i < planets.length; i++) {
                if (planets[i].getName().equals(preference)) {
                    if (canAccept(planets[i], nextPerson)) {
                        return planets[i];
                    }
                    else {
                        return null;
                    }
                }
            }
        }
        else {
            Planet[] copyPlanet = planets;
            for (int j = 0; j < copyPlanet.length; j++) {
                for (int i = 0; i < copyPlanet.length - 1; i++) {
                    if (copyPlanet[i].compareTo(copyPlanet[i + 1]) < 0) {
                        Planet smallerPlanet = copyPlanet[i];
                        copyPlanet[i] = copyPlanet[i + 1];
                        copyPlanet[i + 1] = smallerPlanet;
                    }
                }
            }
            planets = copyPlanet;
            return getHighestCapacityPlanet(nextPerson);
        }
        return null;        
    }
    
    
    private Planet getHighestCapacityPlanet(Person person) {
        for (int i = 0; i < planets.length; i++) {
            Planet largestPlanet = planets[i];
            if (!largestPlanet.isFull() &&
                (canAccept(largestPlanet, person))) {
                return largestPlanet;
            }
        }
        return null;
    }

    
    /**
     * checks to see if the person can be accepted to
     * planet
     * @return boolean if true or false
     */
    public boolean accept() { 
        if (!applicantQueue.isEmpty()) {
            Person front = applicantQueue.getFront();
            String frontPref = applicantQueue.getFront().getPlanetPreference();
            System.out.print(frontPref);
            switch (getPlanetIndex(frontPref)) {
                case 0:
                    planets[0].addPerson(front);
                    applicantQueue.dequeue();
                    return true;
                case 1:
                    planets[1].addPerson(front);
                    applicantQueue.dequeue();
                    return true;
                case 2:
                    planets[2].addPerson(front);
                    applicantQueue.dequeue();
                    return true;
                default:
                    return false;
            }
        }
        return false;
    }
    
    /**
     * rejects person if needed and signs them up for training
     */
    public void reject() {
        Person rejectedPerson = applicantQueue.dequeue();
        rejectBus.add(rejectedPerson);
    }
    
    /**
     * gets the index of the specified planet
     * @param string
     *          string sequence of specified planet
     * @return value based on index
     */
    public int getPlanetIndex(String string) {
        if (string == null) {
            return -1;
        }
        if (string.contains("1")) {
            return 0;
        }
        else if (string.contains("2")) {
            return 1;
        }
        else if (string.contains("3")) {
            return 2;
        }
        else {
            return -1;
        }
        
    }
}
