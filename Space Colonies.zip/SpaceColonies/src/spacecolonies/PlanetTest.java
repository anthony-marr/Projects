// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;


/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/2/2022
 *
 */
public class PlanetTest extends student.TestCase {
    private Planet planet;
    private Planet samePlanet;
    private Planet largerPlanet;
    private Planet smallerPlanet;
    private Planet smallAg;
    private Planet smallMed;
    private Planet smallTech;
    private Planet smallCap;
    
    private Person person;
    private Person qualPerson;
    private Person lessMed;
    private Person lessTech;
    
    /**
     * Sets up objects to be tested on
     */
    public void setUp() {
        planet = new Planet("Earth", 4, 4, 4, 20);
        samePlanet = new Planet("Earth", 4, 4, 4, 20);
        largerPlanet = new Planet("Jupiter", 5, 5, 5, 30);
        smallerPlanet = new Planet("Mercury", 2, 2, 2, 10);
        smallAg = new Planet("Earth", 3, 3, 3, 20);
        smallMed = new Planet("Earth", 4, 3, 3, 20);
        smallTech = new Planet("Earth", 4, 4, 3, 20);
        smallCap = new Planet("Earth", 4, 4, 4, 10);
        
        person = new Person("Anthony", 3, 3, 3, "");
        qualPerson = new Person("Emma", 5, 5, 5, "");
        lessMed = new Person("Anthony", 4, 3, 4, "");
        lessTech = new Person("Ant", 4, 4, 2, "");
    }
    
    /**
     * tests if the set name method works
     */
    public void testSetName() {
        planet.setName("Mars");
        assertEquals("Mars", planet.getName());
    }
    
    /**
     * tests if the get skills method works
     */
    public void testGetSkills() {
        assertEquals(4, planet.getSkills().getAgriculture());
        assertEquals(4, planet.getSkills().getMedicine());
        assertEquals(4, planet.getSkills().getTechnology());
    }
    /**
     * tests to see if the getPopulation method works
     */
    public void testGetPopulation() {
        samePlanet.addPerson(qualPerson);
        samePlanet.addPerson(qualPerson);
        planet.addPerson(qualPerson);
        planet.addPerson(qualPerson);
        for (int i = 0; i < planet.getPopulation().length; i++) {
            assertEquals(planet.getPopulation()[i], 
                samePlanet.getPopulation()[i]);
        }
        
    }
    
    /**
     * tests to see if the getPopulationSize method works
     */
    public void testGetPopulationSize() {
        samePlanet.addPerson(qualPerson);
        samePlanet.addPerson(qualPerson);
        assertEquals(2, samePlanet.getPopulationSize());
    }
    
    /**
     * tests if the get capacity method works
     */
    public void testGetCapacity() {
        assertEquals(20, planet.getCapacity());
        assertEquals(30, largerPlanet.getCapacity());
    }
    
    /**
     * tests if the getAvailability method works
     */
    public void testGetAvailability() {
        assertEquals(20, planet.getAvailability());
        planet.addPerson(qualPerson);
        assertEquals(19, planet.getAvailability());
    }
    
    /**
     * tests if the is full method works
     */
    public void testIsFull() {
        assertFalse(planet.isFull());
        for (int i = 0; i < planet.getCapacity(); i++) {
            planet.addPerson(qualPerson);
        }
        assertTrue(planet.isFull());
    }
    
    /**
     * test if the isqualified method works
     */
    public void testIsQualified() {
        assertFalse(planet.addPerson(person));
        assertTrue(planet.addPerson(qualPerson));
        assertFalse(planet.addPerson(lessMed));
        assertFalse(planet.addPerson(lessTech));
    }
    
    /**
     * tests if the add person method works
     */
    public void testAddPerson() {
        assertFalse(planet.addPerson(person));
        assertTrue(planet.addPerson(qualPerson));
        for (int i = 0; i < planet.getCapacity(); i++) {
            planet.addPerson(qualPerson);
        }
        assertFalse(planet.addPerson(person));
        assertFalse(planet.addPerson(qualPerson));
    }
    
    /**
     * test is the Tostring method works
     */
    public void testToString() {
        assertEquals(planet.toString(), "Earth, population " +
            "0 (cap: 20), Requires: A >= 4, M >= 4, T >= 4");
    }
    
    /**
     * tests if the compare to method works
     */
    public void testCompareTo() {
        assertEquals(planet.compareTo(largerPlanet), -10);
        assertEquals(planet.compareTo(smallerPlanet), 10);
    }
    
    /**
     * tests if the equals method works
     */
    public void testEquals() {
        assertTrue(planet.equals(samePlanet));
        assertFalse(planet.equals(largerPlanet));
        assertFalse(planet.equals(smallerPlanet));
        assertFalse(planet.equals(smallAg));
        assertFalse(planet.equals(smallMed));
        assertFalse(planet.equals(smallTech));
        assertFalse(planet.equals(smallCap));
    }
}
