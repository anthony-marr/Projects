// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/1/2022
 *
 */
public class SkillSetTest extends student.TestCase {
    private Person person;
    private Person equalPerson;
    private Person smallerPerson;
    private Person biggerPerson;
    private Person moreMed;
    private Person moreTech;
    
    /**
     * sets up objects to be tested on
     */
    public void setUp() {
        person = new Person("Anthony", 4, 3, 5, "Earth");
        equalPerson = new Person("Anthony", 4, 3, 5, "Earth");
        smallerPerson = new Person("Anthony", 2, 2, 2, "Earth");
        biggerPerson = new Person("Anthony", 5, 5, 5, "Earth");
        moreMed = new Person("Anthony", 4, 2, 2, "Earth");
        moreTech = new Person("Anthony", 4, 3, 2, "Earth");
    }
    
    /**
     * tests if the getAgriculture method works
     */
    public void testGetAgriculture() {
        assertEquals(person.getSkills().getAgriculture(), 4);
    }
    
    /**
     * tests if the get Medicine method works
     */
    public void testGetMedicine() {
        assertEquals(person.getSkills().getMedicine(), 3);
    }
    
    /**
     * tests if the getTechnology method works
     */
    public void testGetTechnology() {
        assertEquals(person.getSkills().getTechnology(), 5);
    }
    
    /**
     * tests if the is less that or equal to method works
     */
    public void testIsLessThanOrEqualTo() {
        assertTrue(person.getSkills().isLessThanOrEqualTo(
            biggerPerson.getSkills()));
        assertFalse(person.getSkills().isLessThanOrEqualTo(
            smallerPerson.getSkills()));
        assertFalse(person.getSkills().isLessThanOrEqualTo(
            moreMed.getSkills()));
        assertFalse(person.getSkills().isLessThanOrEqualTo(
            moreTech.getSkills()));
    }
    
    /**
     * tests if the ToString method works
     */
    public void testToString() {
        assertEquals(person.getSkills().toString(), "4, 3, 5");
    }
    
    /**
     * tests if the equals method works
     */
    public void testEquals() {
        assertTrue(person.getSkills().equals(equalPerson.getSkills()));
        assertFalse(person.getSkills().equals(moreTech.getSkills()));
        assertFalse(person.getSkills().equals(moreMed.getSkills()));
        assertFalse(person.getSkills().equals(smallerPerson.getSkills()));
    }
    
    /**
     * tests if the CompareTo works
     */
    public void testCompareTo() {
        assertEquals(person.getSkills().compareTo(
            smallerPerson.getSkills()), 6);
    }
}
