// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/8/2022
 *
 */
public class SpaceColonyDataException extends Exception {
    
    /**
     * sets up DataException
     * @param string
     *          string of exception
     */
    public SpaceColonyDataException(String string) {
        super(string);
    }
}
