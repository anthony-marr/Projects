// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept the actions of 
// those who do.
// -- Anthony Marraccini, amarraccini216

package spacecolonies;

/**
 * 
 * @author Anthony Marraccini, amarraccini216
 * @version 11/1/2022
 *
 */
public class Skillset implements Comparable<Skillset> {
    
    private int agriculture;
    private int medicine;
    private int technology;
    
    /**
     * takes in and sets skill parameters
     * @param ag
     *      the amount of skill in ag
     * @param med
     *      the amount of skill in med
     * @param tech
     *      the amount of sill in tech
     */
    public Skillset(int ag, int med, int tech) {
        this.agriculture = ag;
        this.medicine = med;
        this.technology = tech;
    }
    /**
     * returns the agriculture skill value
     * @return the ag skill value
     */
    public int getAgriculture() {
        return this.agriculture;
    }
    
    /**
     * returns the med skill value
     * @return the med skill value
     */
    public int getMedicine() {
        return this.medicine;
    }
    
    /**
     * returns the tech skill value
     * @return the tech skill value
     */
    public int getTechnology() {
        return this.technology;
    }
    
    /**
     * makes sure they are qualified
     * @param other
     *          other skillset to be compared
     * @return boolean if its smaller or not
     */
    public boolean isLessThanOrEqualTo(Skillset other) {
        if (this.agriculture <= other.agriculture) {
            if (this.medicine <= other.medicine) {
                if (this.technology <= other.technology) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * converts to a string sequence
     * @return string sequence
     */
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(agriculture);
        s.append(", ");
        s.append(medicine);
        s.append(", ");
        s.append(technology);
        return s.toString();
    }
    
    /**
     * compares two objects to see if they're equal
     * @param obj
     *          object able to be compared
     * @return boolean value whether they are equal or not
     */
    public boolean equals(Object obj) {
        Skillset other = (Skillset)obj;
        if (this.agriculture == other.agriculture) {
            if (this.medicine == other.medicine) {
                if (this.technology == other.technology) {
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * compares the skill set
     * @param skills
     *          the skillset that will be compared
     * @return integer of difference
     */
    public int compareTo(Skillset skills) {
        int currentSum = (this.agriculture + this.medicine + this.technology);
        int objectSum = (skills.agriculture + 
            skills.medicine + skills.technology);
        return (currentSum - objectSum);
    }
}
